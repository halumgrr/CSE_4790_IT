import 'package:flutter/material.dart';
import 'main_app.dart';

void main() {
  runApp(const MainApp());
}
